const express = require('express');
const cors = require('cors');
const app = express();
const port = 5000;
const quizRoute = require('./router/quiz')
const jobsheetRoute = require('./router/jobsheet')

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const db = require('./models')
db.sequelize.sync()

app.get('/', (req, res) => {
    res.send('Quzi Express JS');
});

app.use('./api/quizzes', quizRoute)
app.user('./api/jobsheet', jobsheetRoute)

app.listen(port, () => console.log(`pp listening on port htp://localhost:${port}!`));