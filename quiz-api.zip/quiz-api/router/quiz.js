const quizController = require('../controllers/quiz');
const router = require('express').Router();

router.post('/', quizController.create);
router.post('/', quizController.getAll);
router.post('/:id', quizController.findOne);
router.post('/:id', quizController.update);
router.post('/:id', quizController.delete);
router.post('/category/:id', quizController.getByCategoryId);
router.post('/category/:id', quizController.getByLevelId);

module.exports = router;
